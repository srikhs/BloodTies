﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Save_Click(object sender, EventArgs e)
    {

        string conn;
        conn = ConfigurationManager.ConnectionStrings["BloodTiesDbConnectionString"].ToString();

        SqlConnection objsqlconn = new SqlConnection(conn);

        objsqlconn.Open();

        SqlCommand objcmd = new SqlCommand("Insert into DoctorInfo_Tbls(Doctor_Name, Qualifications, Specialization, Contact_Number, Address, ProfessionalFees, ClinicName, Timings) Values('" + TextBox2.Text + "','" + TextBox1.Text + "','" + TextBox5.Text + "','" + TextBox8.Text + "','" + TextBox7.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox6.Text + "')", objsqlconn);

        objcmd.ExecuteNonQuery();
        
    }
}