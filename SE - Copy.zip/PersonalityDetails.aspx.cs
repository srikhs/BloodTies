﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Data.SqlTypes;


    public partial class Default2 : System.Web.UI.Page
    {

    
        protected void Page_Load(object sender, EventArgs e)
        {
      
       

    }
    string strConnString = ConfigurationManager.ConnectionStrings["BloodTiesDbConnectionString"].ToString();
    SqlCommand com;

    protected void Button1_Click(object sender, EventArgs e)
    {
        string field1 = (string)(Session["EmailID"]);
        string leaderTrait = string.Empty;
        string thinkingTrait =string.Empty;
        string activeTrait = string.Empty;
        string extrovertTrait = string.Empty;

        try
        {
            System.Data.DataTable countTb = new System.Data.DataTable();
            countTb.Columns.AddRange(new DataColumn[2] { new DataColumn("QuestionNo"), new DataColumn("Answer") });
            countTb.Rows.Add("Question1", RadioButtonList1.SelectedValue.ToString());
            countTb.Rows.Add("Question2", RadioButtonList2.SelectedValue.ToString());
            countTb.Rows.Add("Question3", RadioButtonList3.SelectedValue.ToString());
            countTb.Rows.Add("Question4", RadioButtonList4.SelectedValue.ToString());
            countTb.Rows.Add("Question5", RadioButtonList5.SelectedValue.ToString());
            countTb.Rows.Add("Question6", RadioButtonList6.SelectedValue.ToString());
            countTb.Rows.Add("Question7", RadioButtonList7.SelectedValue.ToString());
            countTb.Rows.Add("Question8", RadioButtonList8.SelectedValue.ToString());
            countTb.Rows.Add("Question9", RadioButtonList9.SelectedValue.ToString());
            countTb.Rows.Add("Question10", RadioButtonList10.SelectedValue.ToString());
            countTb.Rows.Add("Question11", RadioButtonList11.SelectedValue.ToString());
            countTb.Rows.Add("Question12", RadioButtonList12.SelectedValue.ToString());
            countTb.Rows.Add("Question13", RadioButtonList13.SelectedValue.ToString());

            DataRow[] drs = countTb.Select("Answer='leaders'");
            int leader = drs.Count();
            drs = countTb.Select("Answer='Followers'");
            int follower = drs.Count();
            drs = countTb.Select("Answer='Idealistic'");
            int ideaists = drs.Count();
            drs = countTb.Select("Answer='Rationalistic'");
            int rationlist = drs.Count();
            drs = countTb.Select("Answer='Extrovert'");
            int introvert = drs.Count();
            drs = countTb.Select("Answer='Introvert'");
            int extrovert = drs.Count();
            drs = countTb.Select("Answer='Active'");
            int active = drs.Count();
            drs = countTb.Select("Answer='Inactive'");
            int inactive = drs.Count();

            if (leader > follower)
                leaderTrait = "LEADER";
            else
                leaderTrait = "FOLLOWER";
            if (ideaists > rationlist)
                thinkingTrait = "IDEALIST";
            else
                thinkingTrait = "REALIST";
            if (introvert > extrovert)
                extrovertTrait = "INTROVERT";
            else
                extrovertTrait = "EXTROVERT";
            if (active > inactive)
                activeTrait = "ACTIVE";
            else
                activeTrait = "INACTIVE";

            //Inserting into DB
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=BloodTiesDb;Integrated Security=True");
            com = new SqlCommand("Registration", con);
            com.CommandType = CommandType.Text;
            com.CommandText = "insert into PersonalityMatch_MainTraits_Tbl(UserID,LeadershipTrait,ThinkingTrait) values(@UserId,@LeadershipTrait,@ThinkingTrait)";
            com.CommandText += "insert into PersonalityMatch_OppositeTraits_Tbl(UserID,ActiveTrait,ExtrovertTrait) values (@UserId,@ActiveTrait,@ExtrovertTrait)";
            con.Open();
            SqlParameter p1 = new SqlParameter("UserId", Session["UserID"]);
            SqlParameter p2 = new SqlParameter("LeadershipTrait", leaderTrait);
            SqlParameter p3 = new SqlParameter("ThinkingTrait", thinkingTrait);
            SqlParameter p4 = new SqlParameter("ActiveTrait", activeTrait);
            SqlParameter p5 = new SqlParameter("ExtrovertTrait", extrovertTrait);
            com.Parameters.Add(p1);
            com.Parameters.Add(p2);
            com.Parameters.Add(p3);
            com.Parameters.Add(p4);
            com.Parameters.Add(p5);
            com.ExecuteNonQuery();
            con.Close();
            Response.Redirect("Patient.aspx");
        }
        catch(Exception ex)
        {

        }
    }
}