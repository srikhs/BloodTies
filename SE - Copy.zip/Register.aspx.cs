﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;


public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        //SqlConnection con = new SqlConnection();
        //con.ConnectionString = ConfigurationManager.ConnectionStrings["BloodTiesDbConnectionString"].ToString();
        SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=BloodTiesDb;Integrated Security=True");
        SqlCommand com = new SqlCommand("Registration", con);
        com.CommandType = CommandType.StoredProcedure;
        SqlParameter p1 = new SqlParameter("Email", txtEmail.Text);
        SqlParameter p2 = new SqlParameter("LastName", txtLastName.Text);
        SqlParameter p3 = new SqlParameter("FirstName", txtFirstName.Text);
        SqlParameter p4 = new SqlParameter("Password", txtPassword.Text);
        SqlParameter p5 = new SqlParameter("Address", txtAddress.Text);
        SqlParameter p6 = new SqlParameter("City", txtCity.Text);
        SqlParameter p7 = new SqlParameter("PhoneNo", txtPhoneNo.Text);
        com.Parameters.Add(p1);
        com.Parameters.Add(p2);
        com.Parameters.Add(p3);
        com.Parameters.Add(p4);
        com.Parameters.Add(p5);
        com.Parameters.Add(p6);
        com.Parameters.Add(p7);
        con.Open();
        com.ExecuteNonQuery();
        lblSuccessMessage.Text = "User Registered successfully";
        Registration.Visible = false;
        Success.Visible = true;
        
        }

    protected void txtCity_TextChanged(object sender, EventArgs e)
    {

    }
}